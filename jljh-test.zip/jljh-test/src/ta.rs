use super::di::*;
use qust_ds::prelude::*;


pub trait Ta {
    fn calc_di_kline(&self, di_kline: &DiKline) -> vv32;
    fn calc_di(&self, di: &Di) -> vv32 {
        let res = self.calc_di_kline(&di.di_kline);
        di.valid_filter(res)
    }
    fn calc(&self, di_pool: &DiPool) -> vv32 {
        let mut data_iter = di_pool.data.iter();
        let data_part = data_iter.next().unwrap();
        let mut res = self.calc_di(data_part);
        for data_next in data_iter {
            let mut res_next = self.calc_di(data_next);
            res.iter_mut().zip(res_next.iter_mut())
                .for_each(|(p, n)| {
                    p.append(n);
                });
        }
        res
    }
}


pub struct RetMinMean;


impl Ta for RetMinMean {
    fn calc_di_kline(&self, di_kline: &DiKline) -> vv32 {
        let c = &di_kline.c;
        let v = &di_kline.v;
        let ret = c.iter().zip(c.lag(1.)).zip(v.iter()).zip(di_kline.td.windows(2))
            .map(|(((now, pre), v), date_vec)| {
                if date_vec[0] == date_vec[1] && v != &0. {
                    let ret = (now - pre) / pre;
                    ret / v
                } else {
                    0.
                }
            })
            .collect_vec();
        let mut res = test2(&ret, 30, 15);
        res.insert(0, 0.);
        vec![res]
    }
}



pub fn test2(data: &[f32], n: usize, j: usize) -> Vec<f32> {
    let mut min_mean_manager = MinMeanManager::new(n, j);
    let mut res = Vec::with_capacity(data.len());
    for value in data.iter() {
        let s = min_mean_manager.push(*value);
        res.push(s);
    }
    res
}



struct MinMeanManager {
    v1: Vec<f32>,    
    v2: Vec<usize>, 
    index: usize,    
    capacity: usize, 
    num: usize
}

impl MinMeanManager {
    pub fn new(capacity: usize, num: usize) -> Self {
        Self {
            v1: Vec::with_capacity(capacity),
            v2: Vec::with_capacity(capacity),
            index: 0,
            capacity,
            num,
        }
    }

    pub fn push(&mut self, value: f32) -> f32 {
        if self.v1.len() < self.capacity {
            let pos = self.insert_sorted(value);
            self.update_v2_new_pos(pos);
            self.v2.push(pos);
        } else {
            let old_pos = self.v2.remove(0);
            self.v1.remove(old_pos); 
            let pos = self.insert_sorted(value);
            self.update_v2_old_pos(old_pos);
            self.update_v2_new_pos(pos);
            self.v2.push(pos);
        }

        self.index = (self.index + 1) % self.capacity;

        if self.v1.len() < self.num {
            self.v1.mean()
        } else {
            self.v1[..self.num].mean()
        }
    }

    fn insert_sorted(&mut self, value: f32) -> usize {
        let pos = self.v1.partition_point(|x| x.abs() <= value.abs());
        self.v1.insert(pos, value);
        pos
    }

    fn update_v2_old_pos(&mut self, old_pos: usize) {
        for pos in &mut self.v2 {
            if *pos > old_pos {
                *pos -= 1;
            }
        }
    }
    
    fn update_v2_new_pos(&mut self, new_pos: usize) {
        for pos in &mut self.v2 {
            if *pos >= new_pos {
                *pos += 1;
            }
        }
    }
}

pub fn test3(data: &[f32], n: usize, j: usize) -> Vec<f32> {
    let mut res = data
        .windows(n)
        .map(|x| {
            calc_min_mean_inner(x, j)
        })
        .collect_vec();
    let mut res_head = (1..n)
        .map(|i| {
            data[0..i].mean()
        })
        .collect_vec();
    res_head.append(&mut res);
    res_head
}


fn calc_min_mean_inner(data: &[f32], j: usize) -> f32 {
    let mut data = data.to_vec();
    data.sort_by(|a, b| a.partial_cmp(b).unwrap());
    data[..j].mean()
}