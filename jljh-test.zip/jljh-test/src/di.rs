#![allow(non_camel_case_types, non_upper_case_globals)]
use qust_ds::prelude::*;
use anyhow::{Result, anyhow};
use serde::{Serialize, Deserialize};


#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum Ticker {
    AL,
    AG,
}

pub const ALer: Ticker = Ticker::AL;
pub const AGer: Ticker = Ticker::AG;

#[derive(Clone, Default, Debug, Serialize, Deserialize)]
pub struct Kline {
    pub td: da,
    pub t: dt,
    pub o: f32,
    pub h: f32,
    pub l: f32,
    pub c: f32,
    pub v: f32,
}

#[derive(Clone, Default, Serialize, Deserialize)]
pub struct DiKline {
    #[serde(
        serialize_with = "serialize_vec_da",
        deserialize_with = "deserialize_vec_da"
    )]
    pub td: Vec<da>,
    #[serde(
        serialize_with = "serialize_vec_dt",
        deserialize_with = "deserialize_vec_dt"
    )]
    pub t: vdt,
    pub o: v32,
    pub h: v32,
    pub l: v32,
    pub c: v32,
    pub v: v32,
}

impl DiKline {
    pub fn update(&mut self, kline: Kline) {
        self.td.push(kline.td);
        self.t.push(kline.t);
        self.o.push(kline.o);
        self.h.push(kline.h);
        self.l.push(kline.l);
        self.c.push(kline.c);
        self.v.push(kline.v);
    }

    pub fn slice(&self, range: std::ops::Range<usize>) -> Self {
        Self {
            td: self.td[range.clone()].to_vec(),
            t: self.t[range.clone()].to_vec(),
            o: self.o[range.clone()].to_vec(),
            h: self.h[range.clone()].to_vec(),
            l: self.l[range.clone()].to_vec(),
            c: self.c[range.clone()].to_vec(),
            v: self.v[range.clone()].to_vec(),
        }
    }

    pub fn cat_another(&mut self, right_data: Self) {
        let mut right_data = right_data;
        self.td.append(&mut right_data.td);
        self.t.append(&mut right_data.t);
        self.o.append(&mut right_data.o);
        self.h.append(&mut right_data.h);
        self.l.append(&mut right_data.l);
        self.c.append(&mut right_data.c);
        self.v.append(&mut right_data.v);
    }

    pub fn size(&self) -> usize {
        self.td.len()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HotContract {
    pub contract: String,
    pub start_date: da,
    pub end_date: da,
}

#[derive(Serialize, Deserialize)]
pub struct Di {
    pub ticker: Ticker,
    pub di_kline: DiKline,
    pub hot: HotContract,
    pub valid_range_i: (usize, usize),
}


impl Di {
    pub fn new_from(
        ticker: Ticker,
        di_kline: DiKline,
        hot: HotContract,
    ) -> Result<Self> {
        let start_i_o = di_kline
            .td
            .iter()
            .position(|&x| x == hot.start_date);
        let start_i = match start_i_o {
            Some(start_i) => start_i,
            None => {
                eprintln!(
                    "warn: hot says contract {}'s start date at: {:?}, but data start at: {:?}", 
                    hot.contract, 
                    hot.start_date,
                    di_kline.td[0],
                );
                0
            }
        };
        let end_i_o = di_kline
            .td
            .iter()
            .rev()
            .position(|&x| x == hot.end_date);
        let end_i = match end_i_o {
            Some(end_i) => {
                di_kline.size() - end_i
            }
            None => {
                eprintln!(
                    "warn: hot says contract {}'s end  date at: {:?}, but data end  at: {:?}", 
                    hot.contract, 
                    hot.end_date,
                    *di_kline.td.last().unwrap(),
                );
                di_kline.size()
            }
        };
        Ok(Self {
            ticker,
            di_kline,
            hot,
            valid_range_i: (start_i, end_i),
        })

    }
    pub fn valid_filter(&self, data: vv32) -> vv32 {
        data
            .into_iter()
            .map(|x| x[self.valid_range_i.0..self.valid_range_i.1].to_vec())
            .collect_vec()
    }

    pub fn get_valid_di_kline(&self) -> DiKline {
        self.di_kline.slice(self.valid_range_i.0 .. self.valid_range_i.1)
    }

    pub fn get_valid_time_vec(&self) -> vdt {
        self.di_kline.t[self.valid_range_i.0 .. self.valid_range_i.1].to_vec()
    }
}

#[derive(Serialize, Deserialize)]
pub struct DiPool {
    pub data: Vec<Di>,
}

impl DiPool {
    pub fn describe(&self) {
        let contract_len = self.data.len();
        let total_len = self.data
            .iter()
            .fold(0, |mut accu, x| {
                accu += x.di_kline.size();
                accu
            });
        let valid_len = self
            .data
            .iter()
            .fold(0, |mut accu, x| {
                accu += x.valid_range_i.1 - x.valid_range_i.0;
                accu
            });
        println!(
            "    start date: {:?}, end date: {:?}",
            self.data[0].di_kline.td[self.data[0].valid_range_i.0],
            self.data.last().unwrap().di_kline.td[self.data.last().unwrap().valid_range_i.1 - 1],
        );
        println!("    contract size: {} \n    total size: {} \n    valid size: {}", contract_len, total_len, valid_len);
    }

    pub fn get_valid_time_vec(&self) -> vdt {
        self
            .data
            .iter()
            .map(|x| x.get_valid_time_vec())
            .collect_vec()
            .concat()
    }
}