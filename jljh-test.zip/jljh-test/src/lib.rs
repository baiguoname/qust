pub mod di;
pub mod ta;
pub mod config;
pub mod get_data;

pub mod prelude {
    pub use super::di::*;
    pub use super::ta::*;
    pub use super::config::*;
    pub use super::get_data::*;
}