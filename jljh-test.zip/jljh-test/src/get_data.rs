use csv::StringRecord;
use qust_ds::prelude::*;
use super::di::*;
use super::config::*;
use anyhow::{Result, anyhow};


impl TryFrom<StringRecord> for Kline {
    type Error = anyhow::Error;
    fn try_from(value: StringRecord) -> Result<Self, Self::Error> {
        let res = Self {
            td: da::parse_from_str(&value[2], "%Y.%m.%d")?,
            t: dt::parse_from_str(&value[3], "%Y.%m.%dT%H:%M:%S%.f")?,
            o: value[4].parse()?, 
            h: value[5].parse()?,
            l: value[6].parse()?,
            c: value[7].parse()?,
            v: value[9].parse()?,
        };
        Ok(res)
    }
}


pub trait ParseFromCsv<Input>: Sized {
    fn parse_from_csv(input: Input) -> Result<Self>;
}



impl ParseFromCsv<(Ticker, &str)> for Hot  {
    fn parse_from_csv(input: (Ticker, &str)) -> Result<Self> {
        let ticker_str = input.0.debug_string();
        let mut contract_vec = vec![];
        let mut date_vec = vec![];
        let mut reader = csv::Reader::from_path(input.1)?;
        for record in reader.records() {
            let record = record.unwrap();
            if record[1] != ticker_str {
                continue;
            }
            contract_vec.push(record[0].to_string());
            date_vec.push(record[2].to_string());
        }
        let grp = Grp(contract_vec);
        let res_pre = grp.apply(&date_vec, |x| {
            (x.first().unwrap().clone(), x.last().unwrap().clone())
        });
        let mut res = Vec::with_capacity(res_pre.0.len());
        for (contract, (start_date_str, end_date_str)) in res_pre.0.into_iter().zip(res_pre.1.into_iter()) {
            let start_date = da::parse_from_str(&start_date_str, "%Y.%m.%d")?;
            let end_date = da::parse_from_str(&end_date_str, "%Y.%m.%d")?;
            let host_contract = HotContract { contract, start_date, end_date };
            res.push(host_contract);
        }
        let res = Self { data: res };
        Ok(res)
    }
}


#[derive(Clone, Debug)]
pub struct DiPoolParser {
    pub ticker: Ticker,
    pub hot: Hot,
}

fn _extract_contract_i(data: &str) -> Result<i32> {
    let re = regex::Regex::new(r"\d+")?;
    let res = re.find(data).ok_or(anyhow!("contract string not contain number?"))?;
    let contract_i = data[res.start()..res.end()].parse::<i32>()?;
    Ok(contract_i)
}

impl ParseFromCsv<(DiPoolParser, &str)> for DiPool {
    fn parse_from_csv(input: (DiPoolParser, &str)) -> Result<Self> {
        let ticker_str = input.0.ticker.debug_string();
        let mut reader = csv::Reader::from_path(input.1)?;
        let mut data_processing = hm::new();
        let mut data_finished = vec![];
        for hot_contract in input.0.hot.data.into_iter() {
            data_processing.insert(
                hot_contract.contract.clone(), 
                (hot_contract, DiKline::default()),
            );
        }
        for record in reader.records() {
            let record = record.unwrap();
            if record[1] != ticker_str {
                continue;
            }
            if !data_processing.contains_key(&record[0]) {
                continue;
            }
            let Some(p_data) = data_processing.get_mut(&record[0]) else {
                continue;
            };
            let td = da::parse_from_str(&record[2], "%Y.%m.%d")?;
            if td > p_data.0.end_date {
                let contract = p_data.0.contract.clone();
                let (hot_contract, di_kline) = data_processing.remove(&contract).unwrap();
                let di = Di::new_from( input.0.ticker, di_kline, hot_contract)?;
                data_finished.push(di);
            } else {
                let kline = Kline::try_from(record)?;
                p_data.1.update(kline);
            }
        }
        for (_, (hot_contract, di_kline)) in data_processing.into_iter() {
            if di_kline.size() == 0 {
                continue;
            }
            let di = Di::new_from( input.0.ticker, di_kline, hot_contract)?;
            data_finished.push(di);
        }
        data_finished
            .iter_mut()
            .sorted_by(|a, b| Ord::cmp(&a.hot.contract, &b.hot.contract));
        let res = Self { data: data_finished };
        Ok(res)
    }
}

pub trait WriteCsv {
    fn write_csv(&self, p: &str) -> Result<()>;
}

impl WriteCsv for (&DiPool, vv32, Vec<String>) {
    fn write_csv(&self, p: &str) -> Result<()> {
        let t_vec = self.0.get_valid_time_vec();
        let mut wtr = csv::Writer::from_path(p)?;
        wtr.write_record(&self.2)?;
        for i in 0..t_vec.len() {
            let record = self.1
                .iter()
                .fold(vec![t_vec[i].to_string()], |mut accu, x| {
                    accu.push(x[i].to_string());
                    accu
                });
            wtr.write_record(&record)?;
        }
        Ok(())
    }
}