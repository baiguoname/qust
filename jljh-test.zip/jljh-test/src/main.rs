use jljh_test::prelude::*;
use qust_ds::prelude::*;

// const DATA_PATH: &str = "./data";
const DATA_PATH: &str = "/root/qust/notebook/jljh-test/data";

macro_rules! t_ret {
    ($info: expr, $calc: expr) => {
        {
            let timer = std::time::Instant::now();
            let res = $calc;
            println!("{}: {:?}", $info, timer.elapsed());
            res
        }
    };
}


fn main() {
    let ticker = AGer;
    let hot = Hot::parse_from_csv((ticker, &format!("{}/hots.csv", DATA_PATH))).unwrap();
    let di_pool_parser = DiPoolParser {
        ticker,
        hot: hot.clone()
    };
    let middle_data_path = format!("{}/di_pool", DATA_PATH);
    println!("处理中间数据并存储起来, 中间数据位置：{}", middle_data_path);
    let di_pool = DiPool::parse_from_csv((di_pool_parser, &format!("{}/M1_UD.csv", DATA_PATH))).unwrap();
    di_pool.sof("di_pool", DATA_PATH);

    println!("读取中间数据：");
    let di_pool = t_ret!("读取数据耗时：", DiPool::rof("di_pool", DATA_PATH));

    println!("数据信息: ");
    di_pool.describe();

    println!("计算因子：");
    let factor_ret_res = t_ret!("计算因子耗时: ", RetMinMean.calc(&di_pool));


    let res_csv_path = format!("{}/factor_res.csv", DATA_PATH);
    println!("因子结果存入csv，路径为: {:?}", res_csv_path);

    (&di_pool, factor_ret_res, vec!["time".to_string(), "factor_value".to_string()]).write_csv(&res_csv_path).unwrap();


}
