use crate::di::HotContract;




#[derive(Debug, Clone)]
pub struct Hot {
    pub data: Vec<HotContract>,
}


