
# jljh-test
测试计算因子耗时

## Prepare
程序入口文件`./src/main.rs`中变量`DATA_PATH`设定数据文件夹的路径，文件夹中需要包含：
1. `hot.csv`，主力合约文件
2. `M1_UD.csv`，数据文件

## Run
运行`cargo run --release`

## Result
因子计算结果会存储至csv文件
本地测试系统信息：
```
OS: Ubuntu 22.04.4 LTS on Windows 10 x86_64 
Kernel: 5.15.133.1-microsoft-standard-WSL2 
Uptime: 7 hours, 5 mins 
Packages: 1176 (dpkg), 8 (snap) 
Shell: bash 5.1.16 
Theme: Adwaita [GTK3] 
Icons: Adwaita [GTK3] 
Terminal: vscode 
CPU: 12th Gen Intel i7-12700K (20) @ 3.609GHz 
GPU: b07f:00:00.0 Microsoft Corporation Device 008e 
Memory: 10239MiB / 120752MiB 
```
本地单线程计算测试结果：
```
处理中间数据并存储起来, 中间数据位置：/root/qust/notebook/jljh-test/data/di_pool
warn: hot says contract AG1906's start date at: 2018-11-05, but data start at: 2019-01-02
warn: hot says contract AG2504's end  date at: 2025-01-16, but data end  at: 2025-01-15
读取中间数据：
读取数据耗时：: 72.199035ms
数据信息: 
    start date: 2019-01-02, end date: 2025-01-15
    contract size: 20 
    total size: 2229975 
    valid size: 779970
计算因子：
计算因子耗时: : 259.578971ms
因子结果存入csv，路径为: "/root/qust/notebook/jljh-test/data/factor_res.csv"
```

## 说明
1. 为什么要存储中间数据？中间数据可以复用，占用硬盘小，io快
2. 我觉得`手数计算`应该另外做一个服务，每天计算后存储数据库，不应该和因子在一起，所以这里面没测这个。
